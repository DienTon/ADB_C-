﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            using (var fs = new System.IO.FileStream("Screen.png", System.IO.FileMode.Open))
            {
                var bmp = new Bitmap(fs);
                label1.Text = bmp.Size.Width + " " + bmp.Size.Height;
                pictureBox1.Refresh();
                pictureBox1.Size = new Size(bmp.Size.Width, bmp.Size.Height);
                pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                pictureBox1.Image = (Image)bmp.Clone();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String text = tname.Text + ".png";
            pictureBox2.Image.Save(text, ImageFormat.Png);
            MessageBox.Show("Save " + text + "Thành Công");

        }
        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                label1.Text = "Size :" + rectW + " " + rectH;
                Cursor = Cursors.Default;
                Bitmap bmp2 = new Bitmap(pictureBox1.Width, pictureBox1.Height);
                pictureBox1.DrawToBitmap(bmp2, pictureBox1.ClientRectangle);

                Bitmap  crpImg = new Bitmap(rectW, rectH);
                Tb1.Text = "adb shell input tap " + crpX + " " + crpY;
                for (int i = 0; i < rectW; i++)
                {
                    for (int y = 0; y < rectH; y++)
                    {
                        Color pxlclr = bmp2.GetPixel(crpX + i, crpY + y);
                        crpImg.SetPixel(i, y, pxlclr);
                    }
                }

                pictureBox2.Image = (Image)crpImg;
                pictureBox2.SizeMode = PictureBoxSizeMode.CenterImage;
            }
            catch { }
            

        }

        int crpX, crpY, rectW, rectH;
        public Pen crpPen = new Pen(Color.Red);
        private void bLoad_Click(object sender, EventArgs e)
        {
            label1.Text = CmdADB("devices");
            //MessageBox.Show(label1.Text.Length.ToString());
            if (label1.Text.Length > 30)
            {
               
                CmdADB("shell /system/bin/screencap -p /sdcard/Screen1.png");
                Thread.Sleep(500);
                CmdADB("pull /sdcard/Screen1.png Screen1.png");
                using (var fs = new System.IO.FileStream("Screen1.png", System.IO.FileMode.Open))
                {
                    var bmp = new Bitmap(fs);
                    label1.Text = bmp.Size.Width + " " + bmp.Size.Height;
                    pictureBox1.Refresh();
                    pictureBox1.Size = new Size(bmp.Size.Width, bmp.Size.Height);
                    pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                    pictureBox1.Image = (Image)bmp.Clone();
                    pictureBox1.Image.Save("Screen.png", ImageFormat.Png);
                }
            }

        }

        String CmdADB(String Text)
        {
            Process p = new Process();
            ProcessStartInfo i = new ProcessStartInfo();
            i.WindowStyle = ProcessWindowStyle.Hidden;
            i.CreateNoWindow = true;
            i.UseShellExecute = false;
            i.RedirectStandardOutput = true;
            i.FileName = "adb.exe";
            p.StartInfo = i;
            i.Arguments = Text;
            p.Start();
            String KQ = p.StandardOutput.ReadToEnd();
            p.Close();
            return KQ;
        }

        private void bCopy_Click(object sender, EventArgs e)
        {
            if (Tb1.Text.Length > 0)
            {
                Clipboard.SetText(Tb1.Text);
            }
            
        }

        private void bClick_Click(object sender, EventArgs e)
        {
            if (Tb1.Text.Length > 0)
            {
                CmdADB(Tb1.Text.Replace("adb ",""));
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Tb1.Text = "adb shell input tap " + crpX + " " + crpY;
        }

        private void pictureBox1_DoubleClick(object sender, EventArgs e)
        {
            pictureBox1.Refresh();
            //MessageBox.Show("OK");
        }

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
              crpPen.Width = 2;
              base.OnMouseDown(e);

              if (e.Button == System.Windows.Forms.MouseButtons.Left)
              {
                  Cursor = Cursors.Cross;
                  //crpPen.DashStyle = System.Drawing.Drawing2D.DashStyle.Dot;
                  crpX = e.X;
                  crpY = e.Y;

              }
        }

        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Left)
            {
                pictureBox1.Refresh();
                rectW = e.X - crpX;
                rectH = e.Y - crpY;
                Graphics g = pictureBox1.CreateGraphics();
                g.DrawRectangle(crpPen, crpX, crpY, rectW, rectH);
                g.Dispose();
            }
        }
    }
}
